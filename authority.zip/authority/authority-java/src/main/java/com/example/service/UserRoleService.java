package com.example.service;

import com.example.entity.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author   
 * @since 2023-01-09
 */
public interface UserRoleService extends IService<UserRole> {

}
