package com.example.service;

import com.example.entity.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author   
 * @since 2023-01-09
 */
public interface RoleMenuService extends IService<RoleMenu> {

}
