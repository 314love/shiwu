package com.example.service;

import com.example.entity.Help;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 失物求助管理 服务类
 * </p>
 *
 * @author ren
 * @since 2023-02-13
 */
public interface HelpService extends IService<Help> {

}
