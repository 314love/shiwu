package com.example.common;

import com.example.controller.dto.MenuDto;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Result implements Serializable{

	private int code;
	private String msg;
	private Object data;

	public static Result success(Object data) {
		return success(200, "操作成功", data);
	}

	public static Result success(int code, String msg, Object data) {
		Result r = new Result();
		r.setCode(code);
		r.setMsg(msg);
		r.setData(data);
		return r;
	}

	public static Result error(String msg) {
		return error(400, msg, null);
	}

	public static Result error(int code, String msg, Object data) {
		Result r = new Result();
		r.setCode(code);
		r.setMsg(msg);
		r.setData(data);
		return r;
	}
}
