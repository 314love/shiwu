package com.example.common;/*
 * Copyright (c) 2023. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

/**
 * @Description
 * @Author
 * @Data 2023/1/9 17:12
 */

public class Constant {
    public static final String CAPTCHA_KEY="captcha";
    public static final Long DEFUALT_ROLE= Long.valueOf(3);
}
