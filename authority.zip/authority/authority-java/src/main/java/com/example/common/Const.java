package com.example.common;


public class Const {

	public final static String CAPTCHA_KEY = "captcha";

	public final static Integer STATUS_ON = 0;
	public final static Integer STATUS_OFF = 1;

	public static final String DEFULT_PASSWORD = "888888";
	public static final String DEFULT_AVATAR = "http://localhost:8888/files/1673529559138083.jpeg";
}
