<template>
  <v-form-designer class="box"></v-form-designer>
</template>

<script>
export default {
  name: "CreateForm"
}
</script>

<style scoped>
body {
  width: 90%;
  margin: 0;  /* 如果页面出现垂直滚动条，则加入此行CSS以消除之 */
}

</style>
